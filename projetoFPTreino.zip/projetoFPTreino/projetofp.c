

/* tarefas a executar:
as consultas das submissoes quando não encontram dados não estao a fz nada - mostrar mensagem que nao encontrou dados
apagar comentários que não são precisos  */

#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

// constantes associadas aos Estudantes
#define MAX_NOME_ESTUDANTE 100
#define MIN_NUMERO_ESTUDANTE 2200000
#define MAX_NUMERO_ESTUDANTE 2399999
#define MAX_EMAIL 50

// constantes associadas as fichas
#define MAX_NOME_FICHA 100

// constantes associadas aos exercicios
#define MAX_NOME_EXERCICIO 100
#define MAX_EXERCICIOS_FICHA 10

// constantes associadas as submissoes
#define MAX_LINHAS 10000
#define MAX_CLASSIFICACAO 20
#define MIN_CLASSIFICACAO 0

// constantes de limitacao dos dados
#define MAX_ESTUDANTES 100
#define MAX_FICHAS 10
#define MAX_EXERCICIOS 100
#define MAX_SUBMISSAO 10000

//****************************************************************FINAL DAS CONSTANTES

// falta fazer validação de introdução maxima de dados(estudantes, etc)
// fazer validações dos ficheiros binarios para ver se os ficheiros estão corretos

// TYPEDEF
typedef struct
{
    int ano;
    int mes;
    int dia;
} t_data;

typedef struct
{
    int id;
    int numero;
    char nome[MAX_NOME_ESTUDANTE];
    char email[MAX_EMAIL];
} t_estudante;

typedef struct
{
    int id;
    char nome[MAX_NOME_FICHA];
    int numero_exercicios;
    t_data data_ficha;
} t_ficha;

typedef struct
{
    int id;
    int id_ficha;
    char nome[MAX_NOME_EXERCICIO];
    char dificuldade[10];
    char solucao[10];
} t_exercicio;

typedef struct
{
    int id;
    int id_estudante;
    int id_ficha;
    int id_exercicio;
    t_data data_submissao;
    int linhas;
    float classificacao;
} t_submissao;

// prototipos das funcoes

void ler_Dados(t_estudante[], int *, t_ficha[], int *, t_exercicio[], int *, t_submissao[], int *);
void guardar_dados(t_estudante[], int, t_ficha[], int, t_exercicio[], int, t_submissao[], int);
void pedeString(char[], int, char[]);
int pedeInteiro(char[], int, int);
float pedeFloat(char[], int, int);
void pedeEmail(char[], int, char[]);
t_data pedeData(char[]);
int comparaDatas(t_data, t_data);
char pedeSN(char[]);
char menu_principal(void);
char menu_estudantes(void);
char menu_fichas(void);
char menu_exercicios(void);
char menu_submissao(void);
char menu_estatisticas(void);
char menu_dificuldade(void);
char menu_solucao(void);
int novo_estudante(t_estudante[], int);
void todos_estudantes(t_estudante[], int);
int numero_estudantes(t_estudante[], int);
int procura_estudante(t_estudante[], int, int);
int nova_ficha(t_ficha[], int);
void todas_fichas(t_ficha[], int);
int novo_exercicio(t_ficha[], int, t_exercicio[], int);
void todos_exercicios(t_ficha[], int, t_exercicio[], int);
void exercicios_fichas(t_ficha[], int, t_exercicio[], int);
int exercicios_de_ficha(t_ficha[], int, t_exercicio[], int, int);
int nova_submissao(t_estudante[], int, t_ficha[], int, t_exercicio[], int, t_submissao s[], int);
void todas_submissoes(t_estudante[], int, t_ficha[], int, t_exercicio[], int, t_submissao[], int);
void submissoes_estudante(t_estudante[], int, t_ficha[], int, t_exercicio[], int, t_submissao[], int);
void submissoes_ficha(t_estudante[], int, t_ficha[], int, t_exercicio[], int, t_submissao[], int);
void submissoes_sem_classificacao(t_estudante[], int, t_ficha[], int, t_exercicio[], int, t_submissao[], int);
void alterar_classificacao(t_estudante[], int, t_ficha[], int, t_exercicio[], int, t_submissao[], int);
void submissoes_exercicio(t_estudante[], int, t_ficha[], int, t_exercicio[], int, t_submissao[], int);
void total_submissoes_estudante(t_estudante[], int, t_submissao[], int, int);
void media_submissoes_estudante(t_estudante[], int, t_submissao[], int, int);
void percentagem_resolvidos_ficha(t_estudante[], int, t_ficha[], int, t_submissao[], int, int);
void atualiza_solucao(t_exercicio[], int);
void atualiza_dificuldade(t_exercicio[], int);
int pedeDia(t_data);
int apoio_nova_submissao(t_estudante[], t_ficha[], int, t_exercicio[], int, t_submissao[], int, int, int, int);
void encontrar_ficha_id(t_ficha[], int);
int procura_ficha_id(t_ficha[], int, int);
void data_procura(t_ficha[], int);
void estatistica_alunos(t_submissao[], int);
void procura_estudante_nome(t_estudante[], int);

// fim dos prototipos

// função main
int main(void)
{

    int n_estudantes = 0, n_fichas = 0, n_exercicios = 0, n_submissoes = 0; // contadores dos valores preenchidos nos vetores
    char opcao, opcao_fechar, opcao_submenu;                                // opcoes
    t_estudante estudantes[MAX_ESTUDANTES];
    t_ficha fichas[MAX_FICHAS];
    t_exercicio exercicios[MAX_EXERCICIOS];
    t_submissao submissoes[MAX_SUBMISSAO];
    int contador, id_ficha;
    // declaracao dos arrays
    ler_Dados(estudantes, &n_estudantes, fichas, &n_fichas, exercicios, &n_exercicios, submissoes, &n_submissoes);

    do
    {
        opcao = menu_principal();
        switch (opcao)
        {
        case 'a':
            do
            {
                opcao_submenu = menu_estudantes();
                switch (opcao_submenu)
                {
                case 'a':
                    n_estudantes = novo_estudante(estudantes, n_estudantes);
                    break;
                case 't':
                    todos_estudantes(estudantes, n_estudantes);
                    while (getchar() != '\n')
                        ;
                    getchar();
                    break;
                case 'c':
                    numero_estudantes(estudantes, n_estudantes);
                    break;
                case 'w':
                    procura_estudante_nome(estudantes, n_estudantes);

                    break;
                default:
                    break;
                    return 0;
                }
            } while (opcao_submenu != 'v');

            break;
        case 'f':
            do
            {
                opcao_submenu = menu_fichas();
                switch (opcao_submenu)
                {
                case 'a':
                    n_fichas = nova_ficha(fichas, n_fichas);
                    break;
                case 't':
                    todas_fichas(fichas, n_fichas);
                    while (getchar() != '\n')
                        ;
                    getchar();
                    break;
                case 'w':
                    encontrar_ficha_id(fichas, n_fichas);
                    break;
                case 'c':
                    data_procura(fichas, n_fichas);
                    break;

                default:
                    break;
                }
            } while (opcao_submenu != 'v');

            break;
        case 'e':
            do
            {
                opcao_submenu = menu_exercicios();
                switch (opcao_submenu)
                {
                case 'a':
                    n_exercicios = novo_exercicio(fichas, n_fichas, exercicios, n_exercicios);
                    break;
                case 't':
                    todos_exercicios(fichas, n_fichas, exercicios, n_exercicios);
                    break;
                case 'm':
                    exercicios_fichas(fichas, n_fichas, exercicios, n_exercicios);
                    break;
                default:
                    break;
                }
            } while (opcao_submenu != 'v');
            break;
        case 'z':
            do
            {
                opcao_submenu = menu_submissao();
                switch (opcao_submenu)
                {
                case 'a':
                    n_submissoes = nova_submissao(estudantes, n_estudantes, fichas, n_fichas, exercicios, n_exercicios, submissoes, n_submissoes);
                    break;
                case 'f':
                    todas_submissoes(estudantes, n_estudantes, fichas, n_fichas, exercicios, n_exercicios, submissoes, n_submissoes);
                    break;
                case 'e':
                    submissoes_estudante(estudantes, n_estudantes, fichas, n_fichas, exercicios, n_exercicios, submissoes, n_submissoes);
                    break;
                case 'q':
                    submissoes_ficha(estudantes, n_estudantes, fichas, n_fichas, exercicios, n_exercicios, submissoes, n_submissoes);
                    break;
                case 'w':
                    submissoes_sem_classificacao(estudantes, n_estudantes, fichas, n_fichas, exercicios, n_exercicios, submissoes, n_submissoes);
                    break;
                case 'c':
                    alterar_classificacao(estudantes, n_estudantes, fichas, n_fichas, exercicios, n_exercicios, submissoes, n_submissoes);
                    break;
                case 'x':
                    submissoes_exercicio(estudantes, n_estudantes, fichas, n_fichas, exercicios, n_exercicios, submissoes, n_submissoes);
                    break;
                default:
                    break;
                }
            } while (opcao_submenu != 'v');
            break;
        case 'x':
            do
            {
                opcao_submenu = menu_estatisticas();
                switch (opcao_submenu)
                {
                case 'a':
                    total_submissoes_estudante(estudantes, n_estudantes, submissoes, n_submissoes, n_exercicios);
                    break;
                case 's':
                    media_submissoes_estudante(estudantes, n_estudantes, submissoes, n_submissoes, n_exercicios);
                    break;
                case 'd':
                    percentagem_resolvidos_ficha(estudantes, n_estudantes, fichas, n_fichas, submissoes, n_submissoes, n_exercicios);
                    break;
                case 'w':
                    estatistica_alunos(submissoes, n_submissoes);
                    break;
                default:
                    break;
                }
            } while (opcao_submenu != 'v');
            break;
        case 'g':
            guardar_dados(estudantes, n_estudantes, fichas, n_fichas, exercicios, n_exercicios, submissoes, n_submissoes);
            break;
        default:
            opcao_fechar = pedeSN("\nDeseja fechar a aplicacao [S/N]?");
            break;
        }
    } while (opcao_fechar != 's');
    guardar_dados(estudantes, n_estudantes, fichas, n_fichas, exercicios, n_exercicios, submissoes, n_submissoes);
}

void estatistica_alunos(t_submissao submissoes[], int contador_submissoes)
{
    int contador = 0;
    float classificacao_toal = 0, media = 0;

    system("cls");

    printf("\n %-10s %-16s\n", "MEDIA", "MEDIA ARREDONDADA");
    printf("---------- ----------------- \n");
    for (int indice = 0; indice < contador_submissoes; indice++)
    {
        if (submissoes[indice].classificacao >= 0)
        {
            classificacao_toal = classificacao_toal + submissoes[indice].classificacao;
            contador++;
        }
    }
    media = classificacao_toal / contador;
    printf("%-10.2f %-16.0f\n", media, media);

    getchar();
    getchar();
}

void procura_estudante_nome(t_estudante estudantes[], int contador_estudante)
{
    char nome[MAX_NOME_ESTUDANTE];
    int encontrado = 0;
   

    pedeString("Introduza o nome do estudante", MAX_NOME_ESTUDANTE, nome);
  

    for (int i = 0; i < contador_estudante; i++)
    {
     

        if  ((strcmp (nome, estudantes[i].nome) ==0)) 
        {
            printf(" nome: %s, \n ID: %d, \n email: %s", estudantes[i].nome, estudantes[i].id, estudantes[i].email);
            encontrado = 1;
            break;
        }
    }    
   
    getchar();
   
}




void data_procura(t_ficha fichas[], int contador_fichas)
{
    t_data datautilizador;
    datautilizador = pedeData("insira uma data");
    todas_fichas(fichas, contador_fichas);
    for (int i = 0; i < contador_fichas; i++)
    {
        if (datautilizador.ano > fichas[i].data_ficha.ano)
        {
            printf("\nfichas: %d,%s,%d-%d-%d", fichas[i].id, fichas[i].nome, fichas[i].data_ficha.ano, fichas[i].data_ficha.mes, fichas[i].data_ficha.dia);
        }
        else
        {
            if (datautilizador.ano == fichas[i].data_ficha.ano && datautilizador.mes > fichas[i].data_ficha.mes)
            {
                printf("\nfichas: %d,%s,%d-%d-%d", fichas[i].id, fichas[i].nome, fichas[i].data_ficha.ano, fichas[i].data_ficha.mes, fichas[i].data_ficha.dia);
            }
            else
            {
                if (datautilizador.mes == fichas[i].data_ficha.mes && datautilizador.dia > fichas[i].data_ficha.dia)
                {
                    printf("\nfichas: %d,%s,%d-%d-%d", fichas[i].id, fichas[i].nome, fichas[i].data_ficha.ano, fichas[i].data_ficha.mes, fichas[i].data_ficha.dia);
                }
            }
        }
    }
    getchar();
    getchar();
}

void encontrar_ficha_id(t_ficha fichas[], int contador_fichas)
{
    int id_ficha, id;

    todas_fichas(fichas, contador_fichas);
    id_ficha = pedeInteiro("Indica o ID da ficha", 1, contador_fichas);
    id = procura_ficha_id(fichas, contador_fichas, id_ficha);
    if (id >= 0)
        printf("A ficha selecionada tem %s, %d, %d-%d-%d\n", fichas[id].nome, fichas[id].numero_exercicios, fichas[id].data_ficha.ano, fichas[id].data_ficha.mes, fichas[id].data_ficha.dia);
    else
        printf("erro");
    getchar();
    getchar();
}

// declaração das funções

// ############################################################funções que tratam os ficheiros binarios
// função que lê os dados do ficheiro, chamada no inicio da main()
void ler_Dados(t_estudante estudantes[], int *contador_estudantes, t_ficha fichas[], int *contador_fichas, t_exercicio exercicios[], int *contador_exercicios, t_submissao submissoes[], int *contador_submissoes)
{
    FILE *fldb;
    int estudantes_temp, fichas_temp, exercicios_temp, submissoes_temp;
    fldb = fopen("db.dat", "rb");
    if (fldb == NULL)
    {
        printf("Erro ao carregar os dados do ficheiro!!");
        getchar();
    }
    else
    {
        fread(contador_estudantes, sizeof(int), 1, fldb); // vai ler o numero de utilizadores presente no ficheiro
        fread(contador_fichas, sizeof(int), 1, fldb);     // vai ler o numero de utilizadores presente no ficheiro
        fread(contador_exercicios, sizeof(int), 1, fldb); // vai ler o numero de utilizadores presente no ficheiro
        fread(contador_submissoes, sizeof(int), 1, fldb); // vai ler o numero de utilizadores presente no ficheiro
        estudantes_temp = fread(estudantes, sizeof(t_estudante), *contador_estudantes, fldb);
        fichas_temp = fread(fichas, sizeof(t_ficha), *contador_fichas, fldb);
        exercicios_temp = fread(exercicios, sizeof(t_exercicio), *contador_exercicios, fldb);
        submissoes_temp = fread(submissoes, sizeof(t_submissao), *contador_submissoes, fldb);

        if ((*contador_estudantes != estudantes_temp) || (*contador_fichas != fichas_temp) || (*contador_exercicios != exercicios_temp) || (*contador_submissoes != submissoes_temp))
        {
            printf("\nFicheiro corrompido");
            getchar();
        }
    }
    fclose(fldb);
}

// funcão que guarda os dados dos array no ficheiro, função chamada na opção GUARDAR DADOS e antes do programa terminar
void guardar_dados(t_estudante estudantes[], int contador_estudantes, t_ficha fichas[], int contador_fichas, t_exercicio exercicios[], int contador_exercicios, t_submissao submissoes[], int contador_submissoes)
{
    char resposta;

    resposta = pedeSN("Deseja guardar os dados [S/N]?");
    if (resposta == 's')
    {
        FILE *fldb;

        fldb = fopen("db.dat", "wb");
        fwrite(&contador_estudantes, sizeof(int), 1, fldb);
        fwrite(&contador_fichas, sizeof(int), 1, fldb);
        fwrite(&contador_exercicios, sizeof(int), 1, fldb);
        fwrite(&contador_submissoes, sizeof(int), 1, fldb);

        fwrite(estudantes, sizeof(t_estudante), contador_estudantes, fldb);
        fwrite(fichas, sizeof(t_ficha), contador_fichas, fldb);
        fwrite(exercicios, sizeof(t_exercicio), contador_exercicios, fldb);
        fwrite(submissoes, sizeof(t_submissao), contador_submissoes, fldb);
        fclose(fldb);

        printf("\nOs dados foram guardados com sucesso!!");
        getchar();
        getchar();
    }
}

//*********************************************************************FINAL DAS ESTRUTURAS
// função que pede todas as variaveis string da aplicação
void pedeString(char mensagem[], int tamanho, char valor[])
{
    do
    {
        printf("\n%s ", mensagem);
        fgets(valor, tamanho, stdin);
        valor[strcspn(valor, "\n")] = '\0'; // remove newline character

        if (strlen(valor) >= tamanho)
        {
            printf("\nValor introduzido fora dos limites!!");
        }

    } while (strlen(valor) >= tamanho);
}
int pedeInteiro(char mensagem[], int valorInferior, int valorSuperior)
{
    int valor, flag = 0;
    do
    {
        valor = 0;
        printf("\n%s ", mensagem);
        fflush(stdin);
        flag = scanf("%d", &valor);
        if (flag > 0)
        {
            if ((valor >= valorInferior && valor <= valorSuperior))
                flag = 1;
            else
                flag = 0;
        }
        if (flag <= 0)
        {
            printf("\n\nO valor introduzido nao e valido [%d-%d]!\n", valorInferior, valorSuperior);
            while (getchar() != '\n')
                getchar();
        }
    } while (flag == 0);
    return valor;
}
float pedeFloat(char mensagem[], int valorInferior, int valorSuperior)
{
    int flag = 0;
    float valor = 0;
    do
    {
        valor = 0;
        printf("\n%s ", mensagem);
        fflush(stdin);
        flag = scanf("%f", &valor);
        if (flag == 1)
        {
            if ((valor >= valorInferior && valor <= valorSuperior))
                flag = 1;
            else
                flag = 0;
        }
        if (flag == 0)
        {
            printf("\n\nO valor introduzido nao e valido [%d-%d]!\n", valorInferior, valorSuperior);
            while (getchar() != '\n')
                getchar();
        }
    } while (flag == 0);
    return valor;
}
void pedeEmail(char mensagem[], int tamanho, char valor[]) // confirmar
{
    int foundArroba = 0, foundponto = 0, foundespaco = 0;
    do
    {
        printf("\n%s", mensagem);
        scanf(" %149[^\n]", valor);
        foundArroba = 0;
        foundponto = 0;
        foundespaco = 0;
        if (strlen(valor) <= tamanho)
        {
            for (int i = 0; i < strlen(valor); i++)
            {
                if (valor[i] != ' ')
                {
                    if (valor[i] == '@')
                        foundArroba = 1;
                    if (valor[i] == '.' && foundArroba == 1)
                        foundponto = 1;
                }
                else
                    foundespaco = 1;
            }
        }
        if ((foundespaco == 1) || (foundArroba != 1) || (foundponto != 1) || (strlen(valor) > tamanho))
        {
            printf("\nIntroduza um E-mail valido!!!");
            getchar();
        }
    } while ((foundespaco == 1) || (foundArroba != 1) || (foundponto != 1) || (strlen(valor) > tamanho));
}

// funcao que pede o dia e auxiliar a proxima funcao
int pedeDia(t_data data)
{
    int valido = 0;
    do
    {
        printf("\nIntroduza o dia: ");
        scanf("%d", &data.dia);
        if ((data.mes == 1) || (data.mes == 3) || (data.mes == 5) || (data.mes == 7) || (data.mes == 8) || (data.mes == 10) || (data.mes == 12))
        {
            if ((data.dia > 0) && (data.dia <= 31))
                valido = 1;
            else
            {
                printf("\nIntroduza um dia valido (1 a 31) para o mes indicado!!!");
                getchar();
            }
        }
        else if (data.mes == 2)
        {
            if ((data.dia > 0) && (data.dia <= 29))
                valido = 1;
            else
            {
                printf("\nIntroduza um dia valido (1 a 29) para o mes indicado!!!");
                getchar();
            }
        }
        else
        {
            if ((data.dia > 0) && (data.dia <= 30))
                valido = 1;
            else
            {
                printf("\nIntroduza um dia valido (1 a 30) para o mes indicado!!!");
                getchar();
            }
        }
    } while (valido == 0);
    return data.dia;
}

t_data pedeData(char mensagem[]) // mudar para pedir os valores inteiros da funcao pedeinteiro
{
    t_data data;
    time_t data_atual;    // variavel que vai receber a data atual atraves da funcao time
    struct tm *info_data; // tm é a estrutura que contem a data e hora pela função localtime ( resultado do uso da função time)

    time(&data_atual);                         // vai buscar a data atual
    info_data = localtime(&data_atual);        // converte o valor da data atual para a estrutura
    int ano_atual = info_data->tm_year + 1900; // variavel que vai receber o ano atual

    int valido = 0;
    printf("\n%s", mensagem);
    do
    {
        printf("\nIntroduza o ano: ");
        scanf("%d", &data.ano);
        if (data.ano < 2000 || data.ano > ano_atual)
        {
            printf("\nIntroduza um ano valido!!! ex: 2000 - %d\n", ano_atual);
        }
    } while ((data.ano < 2000) || (data.ano > ano_atual));
    do
    {
        printf("\nIntroduza o mes (1 a 12): ");
        scanf("%d", &data.mes);
        if ((data.mes < 1) || (data.mes > 12))
        {
            printf("\nIntroduza um mes valido!!!");
            getchar();
        }
    } while ((data.mes < 1) || (data.mes > 12));
    data.dia = pedeDia(data);
    return data;
}

char pedeSN(char mensagem[])
{
    char resposta;
    do
    {
        printf("\n%s ", mensagem);
        scanf(" %c", &resposta);
        if ((resposta != 'S') && (resposta != 's') && (resposta != 'N') && (resposta != 'n'))
        {
            printf("\nEsta pergunta e obrigatoria introduza (S/N)!!");
            getchar();
        }
    } while ((resposta != 'S') && (resposta != 's') && (resposta != 'N') && (resposta != 'n'));
    resposta = tolower(resposta);
    return resposta;
}

// **************************************************  final das funcoes que recebem os dados de entrada

// funcoes que criam os menus
char menu_principal(void)
{
    char opcao;
    do
    {
        system("cls");
        printf("***** MENU PRINCIPAL *****\n");
        printf("\n(A) - Estudantes");
        printf("\n(F) - Fichas de Exercicios");
        printf("\n(E) - Exercicios");
        printf("\n(Z) - Submissoes");
        printf("\n(X) - Estatisticas");
        printf("\n(G) - Guardar Dados");
        printf("\n(S) - Sair\n");
        printf("\nIntroduza a sua opcao:");
        scanf(" %c", &opcao);

        if ((opcao != 'A') && (opcao != 'a') && (opcao != 'F') && (opcao != 'f') && (opcao != 'E') && (opcao != 'e') && (opcao != 'X') && (opcao != 'x') && (opcao != 'G') && (opcao != 'g') && (opcao != 'S') && (opcao != 's') && (opcao != 'Z') && (opcao != 'z'))
        {
            printf("\nIntroduza uma opcao valida!!");
            getchar();
            getchar();
        }
    } while ((opcao != 'A') && (opcao != 'a') && (opcao != 'F') && (opcao != 'f') && (opcao != 'E') && (opcao != 'e') && (opcao != 'X') && (opcao != 'x') && (opcao != 'G') && (opcao != 'g') && (opcao != 'S') && (opcao != 's') && (opcao != 'Z') && (opcao != 'z'));
    opcao = tolower(opcao);
    return opcao;
}
char menu_estudantes(void)
{
    char opcao;
    do
    {
        system("cls");
        printf("***** MENU ESTUDANTES *****\n");
        printf("\n(A) - Adicionar Estudantes");
        printf("\n(T) - Consultar Todos");
        printf("\n(C) - Consultar Estudante por Numero");
        printf("\n(W) Consultar estudante por nome");
        printf("\n(V) - Voltar\n");
        printf("\nIntroduza a sua opcao:");
        scanf(" %c", &opcao);

        if ((opcao != 'A') && (opcao != 'a') && (opcao != 'T') && (opcao != 't') && (opcao != 'C') && (opcao != 'c') && (opcao != 'V') && (opcao != 'v') && (opcao != 'W') && (opcao != 'w'))
        {
            printf("\nIntroduza uma opcao valida!!");
            getchar();
            getchar();
        }
    } while ((opcao != 'A') && (opcao != 'a') && (opcao != 'T') && (opcao != 't') && (opcao != 'C') && (opcao != 'c') && (opcao != 'V') && (opcao != 'v') && (opcao != 'W') && (opcao != 'w'));
    opcao = tolower(opcao);
    return opcao;
}
char menu_fichas(void)
{
    char opcao;
    do
    {
        system("cls");
        printf("***** MENU FICHAS *****\n");
        printf("\n(A) - Adicionar Nova Ficha");
        printf("\n W) - Consultar por Id da Ficha");
        printf("\n(C) - VER FICHAS COM DATA");
        printf("\n(T) - Consultar Todas");
        printf("\n(V) - Voltar\n");
        printf("\nIntroduza a sua opcao:");
        scanf(" %c", &opcao);

        if ((opcao != 'A') && (opcao != 'a') && (opcao != 'T') && (opcao != 't') && (opcao != 'V') && (opcao != 'v') && (opcao != 'w') && (opcao != 'W') && (opcao != 'C') && (opcao != 'c'))
        {
            printf("\nIntroduza uma opcao valida!!");
            getchar();
            getchar();
        }
    } while ((opcao != 'A') && (opcao != 'a') && (opcao != 'T') && (opcao != 't') && (opcao != 'V') && (opcao != 'v') && (opcao != 'w') && (opcao != 'W') && (opcao != 'C') && (opcao != 'c'));
    opcao = tolower(opcao);
    return opcao;
}
char menu_exercicios(void)
{
    char opcao;
    do
    {
        system("cls");
        printf("***** MENU EXERCICIOS *****\n");
        printf("\n(A) - Adicionar Novo Exercicio");
        printf("\n(T) - Consultar Todos os Exercicios");
        printf("\n(M) - Consultar Exercicios atribuidos as Fichas");
        printf("\n(V) - Voltar\n");
        printf("\nIntroduza a sua opcao:");
        scanf(" %c", &opcao);

        if ((opcao != 'A') && (opcao != 'a') && (opcao != 'T') && (opcao != 't') && (opcao != 'M') && (opcao != 'm') && (opcao != 'V') && (opcao != 'v'))
        {
            printf("\nIntroduza uma opcao valida!!");
            getchar();
            getchar();
        }
    } while ((opcao != 'A') && (opcao != 'a') && (opcao != 'T') && (opcao != 't') && (opcao != 'M') && (opcao != 'm') && (opcao != 'V') && (opcao != 'v'));
    opcao = tolower(opcao);
    return opcao;
}
char menu_submissao(void)
{
    char opcao;
    do
    {
        system("cls");
        printf("***** MENU Submissoes *****\n");
        printf("\n(A) - Nova Submissao");
        printf("\n(C) - Submeter Classificacao");
        printf("\n(F) - Consultar Todas as Submissoes");
        printf("\n(W) - Consultar Todas as Submissoes sem classificacao atribuida");
        printf("\n(E) - Consultar Submissoes por Estudante");
        printf("\n(Q) - Consultar Submissoes por Ficha");
        printf("\n(X) - Consultar Submissoes por Exercicio");
        printf("\n(V) - Voltar\n");
        printf("\nIntroduza a sua opcao:");
        scanf(" %c", &opcao);

        if ((opcao != 'W') && (opcao != 'w') && (opcao != 'Q') && (opcao != 'q') && (opcao != 'A') && (opcao != 'a') && (opcao != 'F') && (opcao != 'f') && (opcao != 'E') && (opcao != 'e') && (opcao != 'V') && (opcao != 'v') && (opcao != 'C') && (opcao != 'c') && (opcao != 'X') && (opcao != 'x'))
        {
            printf("\nIntroduza uma opcao valida!!");
            getchar();
            getchar();
        }
    } while ((opcao != 'W') && (opcao != 'w') && (opcao != 'Q') && (opcao != 'q') && (opcao != 'A') && (opcao != 'a') && (opcao != 'F') && (opcao != 'f') && (opcao != 'E') && (opcao != 'e') && (opcao != 'V') && (opcao != 'v') && (opcao != 'C') && (opcao != 'c') && (opcao != 'X') && (opcao != 'x'));
    opcao = tolower(opcao);
    return opcao;
}

char menu_estatisticas(void)
{
    char opcao;
    do
    {
        system("cls");
        printf("***** MENU Estatisticas *****\n");
        printf("\n(A) - Total de submissoes de um estudante");
        printf("\n(S) - Media das classificacoes nas submissoes realizadas por um estudante");
        printf("\n(D) - Percentagem de exercicios resolvidos em cada ficha por um estudante");
        printf("\n(W) - Estatistica de todos os estudantes\n");
        printf("\n(V) - Voltar\n");
        printf("\nIntroduza a sua opcao:");
        scanf(" %c", &opcao);

        if ((opcao != 'A') && (opcao != 'a') && (opcao != 'S') && (opcao != 's') && (opcao != 'D') && (opcao != 'd') && (opcao != 'V') && (opcao != 'v') && (opcao != 'W') && (opcao != 'w'))
        {
            printf("\nIntroduza uma opcao valida!!");
            getchar();
            getchar();
        }
    } while ((opcao != 'A') && (opcao != 'a') && (opcao != 'S') && (opcao != 's') && (opcao != 'D') && (opcao != 'd') && (opcao != 'V') && (opcao != 'v') && (opcao != 'W') && (opcao != 'w'));
    opcao = tolower(opcao);
    return opcao;
}

char menu_dificuldade(void)
{
    char opcao;
    do
    {
        system("cls");
        printf("***** Grau de dificuldade do exercicio *****\n");
        printf("\n(B) - Baixo");
        printf("\n(M) - Medio");
        printf("\n(A) - Alto");
        printf("\nIntroduza a sua opcao:");
        scanf(" %c", &opcao);

        if ((opcao != 'A') && (opcao != 'a') && (opcao != 'B') && (opcao != 'b') && (opcao != 'M') && (opcao != 'm'))
        {
            printf("\nIntroduza uma opcao valida!!");
            getchar();
            getchar();
        }
    } while ((opcao != 'A') && (opcao != 'a') && (opcao != 'B') && (opcao != 'b') && (opcao != 'M') && (opcao != 'm'));
    opcao = tolower(opcao);
    return opcao;
}
char menu_solucao(void)
{
    char opcao;
    do
    {
        system("cls");
        printf("***** Tipo de solucao *****\n");
        printf("\n(A) - Algoritmo");
        printf("\n(C) - Codigo");
        printf("\nIntroduza a sua opcao:");
        scanf(" %c", &opcao);

        if ((opcao != 'A') && (opcao != 'a') && (opcao != 'C') && (opcao != 'c'))
        {
            printf("\nIntroduza uma opcao valida!!");
            getchar();
            getchar();
        }
    } while ((opcao != 'A') && (opcao != 'a') && (opcao != 'C') && (opcao != 'c'));
    opcao = tolower(opcao);
    return opcao;
}

// funcoes do menu Estudantes
int novo_estudante(t_estudante estudantes[], int contador)
{
    int existe = 0, numero = 0;
    if (contador < MAX_ESTUDANTES)
    {
        pedeString("Introduza o nome do estudante:", MAX_NOME_ESTUDANTE, estudantes[contador].nome);
        pedeEmail("Introduza o e-mail do estudante:", MAX_EMAIL, estudantes[contador].email);
        do
        {
            existe = 0;
            numero = pedeInteiro("Introduza o numero do estudante:", MIN_NUMERO_ESTUDANTE, MAX_NUMERO_ESTUDANTE);
            if (contador > 0)
            {
                for (int i = 0; i < contador; i++)
                {
                    if (estudantes[i].numero == numero)
                    {
                        existe = 1;
                        printf("\nJa existe um estudante com este numero registado!!");
                    }
                }
            }
        } while (existe != 0);
        estudantes[contador].numero = numero;
        estudantes[contador].id = contador + 1;
        printf("\nEstudante registado com sucesso...");
    }
    else
        printf("\nAtingiu o numero maximo de estudantes suportado pela aplicacao...");
    getchar();
    getchar();
    return contador + 1;
}
void todos_estudantes(t_estudante estudantes[], int contador)
{
    if (contador > 0)
    {
        printf("%-5s%-10s%-50s%-35s\n", "ID", "NUMERO", "NOME", "E-MAIL");
        printf("---- -------- ------------------------------------------------- ------------------------------------\n");
        for (int i = 0; i < contador; i++)
        {
            printf("%-5d%-10d%-50s%-35s\n", estudantes[i].id, estudantes[i].numero, estudantes[i].nome, estudantes[i].email);
        }
    }
    else
    {
        printf("\nAinda nao existem estudantes registados...");
        getchar();
        getchar();
    }
}
int numero_estudantes(t_estudante estudantes[], int contador)
{
    int numero, posicao = -1;
    if (contador > 0)
    {
        // todos_estudantes(estudantes, contador);
        numero = pedeInteiro("Introduza o numero do estudante:", MIN_NUMERO_ESTUDANTE, MAX_NUMERO_ESTUDANTE);
        for (int i = 0; i < contador; i++)
        {
            if (estudantes[i].numero == numero)
            {
                posicao = i;
                break;
            }
        }
        if (posicao == -1)
            printf("\nNao foram encontrados estudantes com o numero indicado!!");
        else
        {
            printf("\n------------------------------");
            printf("\n Num:    %d ", estudantes[posicao].numero);
            printf("\n Nome:   %s ", estudantes[posicao].nome);
            printf("\n E-mail: %s ", estudantes[posicao].email);
            printf("\n------------------------------\n");
        }
    }
    else
        printf("\nAinda nao existem estudantes registados...");
    getchar();
    getchar();
    return posicao;
}

// função que devolve o indice onde se encontra o estudante, e recebe o numero de estudante
int procura_estudante(t_estudante estudantes[], int contador, int numero_estudante)
{
    int procura = -1;

    for (int indice = 0; indice < contador; indice++)
    {
        if (estudantes[indice].numero == numero_estudante)
            procura = indice;
    }
    return procura;
}

// funcao que devolve o indice onde se encontra o estudante, e recebe o id do estudante
int procura_estudante_id(t_estudante estudantes[], int contador, int id_estudante)
{
    int procura = -1;

    for (int indice = 0; indice < contador; indice++)
    {
        if (estudantes[indice].id == id_estudante)
            procura = indice;
    }
    return procura;
}

// funcoes do menu Fichas
int nova_ficha(t_ficha fichas[], int contador)
{
    if (contador < MAX_FICHAS)
    {
        pedeString("Introduza o nome da Ficha:", MAX_NOME_FICHA, fichas[contador].nome);
        fichas[contador].numero_exercicios = pedeInteiro("Introduza o numero de exercicios constantes nesta ficha:", 1, MAX_FICHAS);
        fichas[contador].data_ficha = pedeData("Introduza a data de lancamento desta Ficha:");
        fichas[contador].id = contador + 1;
        printf("\nNova Ficha registada com sucesso...");
        contador++;
    }
    else
    {
        printf("\nAtingiu o numero maximo de fichas suportado pela aplicacao...");
    }
    getchar();
    getchar();
    return contador;
}
void todas_fichas(t_ficha fichas[], int contador)
{
    printf("%-5s%-50s%-15s%-10s\n", "ID", "NOME", "No EXERCICIOS", "DATA");
    printf("---- ------------------------------------------------- ------------- ----------\n");
    for (int i = 0; i < contador; i++)
    {

        printf("%-5d%-50s%-15d%2d/%2d/%-4d\n", fichas[i].id, fichas[i].nome, fichas[i].numero_exercicios, fichas[i].data_ficha.dia, fichas[i].data_ficha.mes, fichas[i].data_ficha.ano);
    }
}
int procura_ficha(t_ficha fichas[], int contador, int id_ficha)
{ /* funcao que devolve o indice onde se encontra a ficha, e recebe o id da ficha */
    int procura = -1;
    for (int indice = 0; indice < contador; indice++)
    {
        if (fichas[indice].id == id_ficha)
            procura = indice;
    }
    return procura;
}

// função que conta os exercicios que uma ficha tem registados
int conta_exercicios(t_exercicio exercicios[], int contador_exercicios, int id_ficha)
{
    int contador = 0;
    for (int indice = 0; indice < contador_exercicios; indice++)
    {
        if (exercicios[indice].id_ficha == id_ficha)
        {
            contador++;
        }
    }
    return contador;
}

// funcoes de apoio menu Exercicios
void atualiza_dificuldade(t_exercicio exercicios[], int contador_exercicios)
{
    char res_menu = menu_dificuldade(); // Chama o menu e guarda a resposta da dificuldade do exercicio

    if (res_menu == 'b')
    {
        strcpy(exercicios[contador_exercicios].dificuldade, "Baixo");
    }
    else if (res_menu == 'm')
    {
        strcpy(exercicios[contador_exercicios].dificuldade, "Medio");
    }
    else
    {
        strcpy(exercicios[contador_exercicios].dificuldade, "Alto");
    }
}
void atualiza_solucao(t_exercicio exercicios[], int contador_exercicios)
{
    char res_menu = menu_solucao(); // Chama o menu e guarda a resposta da solucao do exercicio

    if (res_menu == 'a')
    {
        strcpy(exercicios[contador_exercicios].solucao, "Algoritmo");
    }
    else
    {
        strcpy(exercicios[contador_exercicios].solucao, "Codigo");
    }
}

// funcoes do menu Exercicios
int novo_exercicio(t_ficha fichas[], int contador_fichas, t_exercicio exercicios[], int contador_exercicios)
{
    int id_ficha = 0, indice_ficha = 0, exercicios_ficha = 0;
    char res_menu;
    if (contador_fichas > 0)
    {
        todas_fichas(fichas, contador_fichas);
        id_ficha = pedeInteiro("Introduza o ID da ficha a que pertence o exercicio:", 1, contador_fichas);
        indice_ficha = procura_ficha(fichas, contador_fichas, id_ficha);
        exercicios_ficha = conta_exercicios(exercicios, contador_exercicios, id_ficha);
        if (fichas[indice_ficha].numero_exercicios > exercicios_ficha)
        {
            exercicios[contador_exercicios].id_ficha = id_ficha;
            pedeString("Introduza o nome do Exercicio:", MAX_NOME_EXERCICIO, exercicios[contador_exercicios].nome);
            atualiza_dificuldade(exercicios, contador_exercicios);        // Chama a função que apresenta a dificuldade do exercicio
            atualiza_solucao(exercicios, contador_exercicios);            // Chama a função que apresenta a solução do exercicio
            exercicios[contador_exercicios].id = contador_exercicios + 1; // incrementa o id do exercicio
            contador_exercicios++;                                        // incrementa o contador de exercicios
            printf("\nNovo Exercicio registado com sucesso...");
        }
        else
        {
            printf("\nA ficha selecionada ja tem todos os exercicios registados");
        }
    }
    else
    {
        printf("\nAinda nao existem fichas registadas!!");
    }
    getchar();
    getchar();
    return contador_exercicios; // devolve o contador de exercicios;
}

// lista as fichas com os respetivos exercicios
void exercicios_fichas(t_ficha fichas[], int contador_fichas, t_exercicio exercicios[], int contador_exercicios)
{
    for (int i = 0; i < contador_fichas; i++)
    {
        printf("------------------------------------------------------------------------------------------------------\n");
        printf("Ficha: %s \nNo Exercicios: %d \nData: %2d/%2d/%4d\n\n", fichas[i].nome, fichas[i].numero_exercicios, fichas[i].data_ficha.dia, fichas[i].data_ficha.mes, fichas[i].data_ficha.ano);

        printf("%-50s%-20s%-20s\n", "Exercicio", "DIFICULDADE", "SOLUCAO");
        for (int f = 0; f < contador_exercicios; f++)
        {
            if (exercicios[f].id_ficha == fichas[i].id)
            {
                printf("%-50s%-20s%-20s\n", exercicios[f].nome, exercicios[f].dificuldade, exercicios[f].solucao);
            }
        }
        printf("\n\n");
    }
    getchar();
    getchar();
}

// funcoes que recebem o ID e devolvem a posicao em que estao no vetor
int procura_ficha_id(t_ficha fichas[], int contador_fichas, int id_ficha)
{
    for (int i = 0; i < contador_fichas; i++)
    {
        if (fichas[i].id == id_ficha)
        {
            return i;
        }
    }
    return -1;
}
// funcoes que devolvem o indice
int procura_exercicio(t_exercicio exercicios[], int contador_exercicios, int id_exercicio)
{
    for (int i = 0; i < contador_exercicios; i++)
    {
        if (exercicios[i].id == id_exercicio)
        {
            return i;
        }
    }
    return -1;
}

// listagem de todos os exercicios
void todos_exercicios(t_ficha fichas[], int contador_fichas, t_exercicio exercicios[], int contador_exercicios)
{
    int indice_ficha;
    if (contador_fichas > 0)
    {
        if (contador_exercicios > 0)
        {
            printf("%-5s%-50s%-50s%-20s%-20s\n", "ID", "EXERCICIO", "FICHA", "DIFICULDADE", "SOLUCAO");
            printf("---- ------------------------------------------------- ------------------------------------------------- ------------------- --------------------\n");
            for (int i = 0; i < contador_exercicios; i++)
            {
                indice_ficha = procura_ficha_id(fichas, contador_fichas, exercicios[i].id_ficha);
                printf("%-5d%-50s%-50s%-20s%-20s\n", exercicios[i].id, exercicios[i].nome, fichas[indice_ficha].nome, exercicios[i].dificuldade, exercicios[i].solucao);
            }
        }
        else
            printf("\nAinda nao existem Exercicios registados!!");
    }
    else
        printf("\nAinda nao existem Fichas registadas!!");
    getchar();
    getchar();
}

// lista todos os exercicios de uma ficha e valida a escolha do mesmo
int exercicios_de_ficha(t_ficha fichas[], int contador_fichas, t_exercicio exercicios[], int contador_exercicios, int pos_ficha)
{
    int valor_lido = 0, flag = 0, indice_valor = 0;
    int valor_esperado[MAX_EXERCICIOS_FICHA];
    do
    {
        system("cls");
        // lista todos os exercicios presentes numa ficha
        printf("%-5s%-50s%-50s%-20s%-20s\n", "ID", "EXERCICIO", "FICHA", "DIFICULDADE", "SOLUCAO");
        printf("-------------------------------------------------------------------------------------------------------------------------------------------\n");

        for (int indice = 0; indice < contador_exercicios; indice++)
        {
            if (exercicios[indice].id_ficha == fichas[pos_ficha].id)
            {

                printf("%-5d%-50s%-50s%-20s%-20s\n", exercicios[indice].id, exercicios[indice].nome, fichas[pos_ficha].nome, exercicios[indice].dificuldade, exercicios[indice].solucao);
                valor_esperado[indice_valor] = exercicios[indice].id;
                indice_valor++;
            }
        }
        valor_lido = pedeInteiro("Introduza o ID do exercicio:", 1, MAX_EXERCICIOS);
        for (int indice = 0; indice < indice_valor; indice++)
        {
            if (valor_lido == valor_esperado[indice])
            {
                flag = 1;
            }
        }
    } while (flag == 0);
    return valor_lido;
}

// funcoes do menu submissoes

// função que recebe os id's de(exercicio, ficha e estudante) e verifica se a submissao já se encontra realizada e devolve o indice de submissoes onde se encontra
int procurar_submissao(t_submissao submissoes[], int contador_submissoes, int id_ficha, int id_exercicio, int id_estudante)
{
    int indice_submissao = -1;

    for (int indice = 0; indice < contador_submissoes; indice++)
    {
        if ((submissoes[indice].id_estudante == id_estudante) && (submissoes[indice].id_exercicio == id_exercicio) && (submissoes[indice].id_ficha == id_ficha))
        {
            indice_submissao = indice;
        }
    }
    return indice_submissao;
}

/* apoio à funcao nova_submissao*/
int apoio_nova_submissao(t_estudante estudantes[], t_ficha fichas[], int contador_fichas, t_exercicio exercicios[], int contador_exercicios, t_submissao submissoes[], int contador_submissoes, int indice_ficha, int id_ficha, int indice_estudante)
{
    int id_exercicio, submissao_existente = 0;
    id_exercicio = exercicios_de_ficha(fichas, contador_fichas, exercicios, contador_exercicios, indice_ficha);
    // verificar se o estudante ja realizou a submissao
    submissao_existente = procurar_submissao(submissoes, contador_submissoes, id_ficha, id_exercicio, estudantes[indice_estudante].id);
    if (submissao_existente < 0)
    {
        submissoes[contador_submissoes].data_submissao = pedeData("Introduza a data de lancamento da submissao:");
        submissoes[contador_submissoes].linhas = pedeInteiro("Introdudza o numero de linhas de solucao:", 1, MAX_LINHAS);
        submissoes[contador_submissoes].id = contador_submissoes + 1;
        submissoes[contador_submissoes].id_estudante = estudantes[indice_estudante].id;
        submissoes[contador_submissoes].id_ficha = id_ficha;
        submissoes[contador_submissoes].id_exercicio = id_exercicio;
        submissoes[contador_submissoes].classificacao = -1;
        contador_submissoes++;
        printf("Submissao realizada com sucesso...");
    }
    else
    {
        printf("\nEste aluno ja registou a submissao do exercicio...");
    }
    return contador_submissoes;
}

int nova_submissao(t_estudante estudantes[], int contador_estudantes, t_ficha fichas[], int contador_fichas, t_exercicio exercicios[], int contador_exercicios, t_submissao submissoes[], int contador_submissoes)
{
    int id_ficha, numero_estudante, id_estudante, indice_ficha, indice_estudante, indice_exercicio, contagem_exercicios = 0;

    if (contador_submissoes < MAX_SUBMISSAO)
    {
        system("cls");
        numero_estudante = pedeInteiro("Introduza o numero de estudante:", MIN_NUMERO_ESTUDANTE, MAX_NUMERO_ESTUDANTE);
        indice_estudante = procura_estudante(estudantes, contador_estudantes, numero_estudante);
        if (indice_estudante >= 0)
        {
            todas_fichas(fichas, contador_fichas);
            id_ficha = pedeInteiro("Introduza o ID da ficha a que pertence o exercicio:", 1, contador_fichas);
            indice_ficha = procura_ficha(fichas, contador_fichas, id_ficha);
            if (indice_ficha >= 0)
            {
                contagem_exercicios = conta_exercicios(exercicios, contador_exercicios, id_ficha);
                if (contagem_exercicios > 0)
                    contador_submissoes = apoio_nova_submissao(estudantes, fichas, contador_fichas, exercicios, contador_exercicios, submissoes, contador_submissoes, indice_ficha, id_ficha, indice_estudante);
                else
                    printf("\nA ficha selecionada ainda nao tem exercicios registados!!");
            }
            else
                printf("\nFicha nao encontrada!!");
        }
        else
            printf("\nEstudante nao encontrado!!");
    }
    else
        printf("\nAtingiu o numero maximo de submissoes permitido pela aplicacao!!");
    getchar();
    getchar();
    return contador_submissoes;
}

void todas_submissoes(t_estudante estudantes[], int contador_estudantes, t_ficha fichas[], int contador_fichas, t_exercicio exercicios[], int contador_exercicios, t_submissao submissoes[], int contador_submissoes)
{
    int indice_estudante, indice_ficha, indice_exercicio;

    printf("%-5s %-10s %-50s %-50s %-30s %-6s %-15s\n", "ID", "DATA", "ESTUDANTE", "FICHA", "EXERCICIO", "LINHAS", "CLASSIFICACAO");
    printf("----- ---------- -------------------------------------------------- -------------------------------------------------- ------------------------------ ------ --------------\n");

    for (int indice = 0; indice < contador_submissoes; indice++)
    {
        indice_estudante = procura_estudante_id(estudantes, contador_estudantes, submissoes[indice].id_estudante);
        indice_ficha = procura_ficha(fichas, contador_fichas, submissoes[indice].id_ficha);
        indice_exercicio = procura_exercicio(exercicios, contador_exercicios, submissoes[indice].id_exercicio);
        if (submissoes[indice].classificacao >= 0)
        {
            printf("%-5d%3d/%2d/%-5d%-51s%-51s%-31s%-7d%-16.2f\n", submissoes[indice].id, submissoes[indice].data_submissao.dia, submissoes[indice].data_submissao.mes, submissoes[indice].data_submissao.ano, estudantes[indice_estudante].nome, fichas[indice_ficha].nome, exercicios[indice_exercicio].nome, submissoes[indice].linhas, submissoes[indice].classificacao);
        }
        else
        {
            printf("%-5d%3d/%2d/%-5d%-51s%-51s%-31s%-7d%-16s\n", submissoes[indice].id, submissoes[indice].data_submissao.dia, submissoes[indice].data_submissao.mes, submissoes[indice].data_submissao.ano, estudantes[indice_estudante].nome, fichas[indice_ficha].nome, exercicios[indice_exercicio].nome, submissoes[indice].linhas, "Nao atribuida");
        }
    }
    getchar();
    getchar();
}

void submissoes_sem_classificacao(t_estudante estudantes[], int contador_estudantes, t_ficha fichas[], int contador_fichas, t_exercicio exercicios[], int contador_exercicios, t_submissao submissoes[], int contador_submissoes)
{
    int indice_estudante, indice_ficha, indice_exercicio;
    if (contador_submissoes > 0)
    {
        printf("%-5s %-10s %-50s %-50s %-30s %-6s %-15s\n", "ID", "DATA", "ESTUDANTE", "FICHA", "EXERCICIO", "LINHAS", "CLASSIFICACAO");
        printf("----- ---------- -------------------------------------------------- -------------------------------------------------- ------------------------------ ------ --------------\n");
        for (int indice = 0; indice < contador_submissoes; indice++)
        {
            if (submissoes[indice].classificacao < 0)
            {
                indice_estudante = procura_estudante_id(estudantes, contador_estudantes, submissoes[indice].id_estudante);
                indice_ficha = procura_ficha(fichas, contador_fichas, submissoes[indice].id_ficha);
                indice_exercicio = procura_exercicio(exercicios, contador_exercicios, submissoes[indice].id_exercicio);
                printf("%-5d%3d/%2d/%-5d%-51s%-51s%-31s%-7d%-16s\n", submissoes[indice].id, submissoes[indice].data_submissao.dia, submissoes[indice].data_submissao.mes, submissoes[indice].data_submissao.ano, estudantes[indice_estudante].nome, fichas[indice_ficha].nome, exercicios[indice_exercicio].nome, submissoes[indice].linhas, "Nao atribuida");
            }
        }
    }
    else
        printf("\nAinda nao foram registadas submissoes!!");
    getchar();
    getchar();
}

void submissoes_estudante(t_estudante estudantes[], int contador_estudantes, t_ficha fichas[], int contador_fichas, t_exercicio exercicios[], int contador_exercicios, t_submissao submissoes[], int contador_submissoes)
{
    int indice_estudante, indice_ficha, indice_exercicio, numero_estudante, contador = 0;

    system("cls");
    numero_estudante = pedeInteiro("Introduza o numero de estudante:", MIN_NUMERO_ESTUDANTE, MAX_NUMERO_ESTUDANTE);
    indice_estudante = procura_estudante(estudantes, contador_estudantes, numero_estudante);
    if (indice_estudante >= 0)
    {
        printf("%-5s %-10s %-50s %-50s %-30s %-6s %-15s\n", "ID", "DATA", "ESTUDANTE", "FICHA", "EXERCICIO", "LINHAS", "CLASSIFICACAO");
        printf("----- ---------- -------------------------------------------------- -------------------------------------------------- ------------------------------ ------ --------------\n");
        for (int indice = 0; indice < contador_submissoes; indice++)
        {
            if (estudantes[indice_estudante].id == submissoes[indice].id_estudante)
            {
                indice_ficha = procura_ficha(fichas, contador_fichas, submissoes[indice].id_ficha);
                indice_exercicio = procura_exercicio(exercicios, contador_exercicios, submissoes[indice].id_exercicio);
                if (submissoes[indice].classificacao >= 0)
                {
                    printf("%-5d%3d/%2d/%-5d%-51s%-51s%-31s%-7d%-16.2f\n", submissoes[indice].id, submissoes[indice].data_submissao.dia, submissoes[indice].data_submissao.mes, submissoes[indice].data_submissao.ano, estudantes[indice_estudante].nome, fichas[indice_ficha].nome, exercicios[indice_exercicio].nome, submissoes[indice].linhas, submissoes[indice].classificacao);
                }
                else
                    printf("%-5d%3d/%2d/%-5d%-51s%-51s%-31s%-7d%-16s\n", submissoes[indice].id, submissoes[indice].data_submissao.dia, submissoes[indice].data_submissao.mes, submissoes[indice].data_submissao.ano, estudantes[indice_estudante].nome, fichas[indice_ficha].nome, exercicios[indice_exercicio].nome, submissoes[indice].linhas, "Nao atribuida");
                contador++;
            }
        }
        if (contador == 0)
            printf("\nO aluno %8d - %s ainda nao realizou nenhuma submissao", estudantes[indice_estudante].numero, estudantes[indice_estudante].nome);
    }
    else
        printf("\nEstudante nao encontrado!!");
    getchar();
    getchar();
}

void submissoes_ficha(t_estudante estudantes[], int contador_estudantes, t_ficha fichas[], int contador_fichas, t_exercicio exercicios[], int contador_exercicios, t_submissao submissoes[], int contador_submissoes)
{
    int indice_estudante, indice_ficha, indice_exercicio, id_ficha;

    system("cls");
    todas_fichas(fichas, contador_fichas);
    id_ficha = pedeInteiro("Introduza o ID da ficha que pretende:", 1, contador_fichas);
    indice_ficha = procura_ficha(fichas, contador_fichas, id_ficha);
    if (indice_ficha >= 0)
    {
        printf("%-5s %-10s %-50s %-50s %-30s %-6s %-15s\n", "ID", "DATA", "ESTUDANTE", "FICHA", "EXERCICIO", "LINHAS", "CLASSIFICACAO");
        printf("----- ---------- -------------------------------------------------- -------------------------------------------------- ------------------------------ ------ --------------\n");
        for (int indice = 0; indice < contador_submissoes; indice++)
        {
            if (fichas[indice_ficha].id == submissoes[indice].id_ficha)
            {
                indice_estudante = procura_estudante_id(estudantes, contador_estudantes, submissoes[indice].id_estudante);
                indice_exercicio = procura_exercicio(exercicios, contador_exercicios, submissoes[indice].id_exercicio);
                if (submissoes[indice].classificacao >= 0)
                {
                    printf("%-5d%3d/%2d/%-5d%-51s%-51s%-31s%-7d%-16.2f\n", submissoes[indice].id, submissoes[indice].data_submissao.dia, submissoes[indice].data_submissao.mes, submissoes[indice].data_submissao.ano, estudantes[indice_estudante].nome, fichas[indice_ficha].nome, exercicios[indice_exercicio].nome, submissoes[indice].linhas, submissoes[indice].classificacao);
                }
                else
                {
                    printf("%-5d%3d/%2d/%-5d%-51s%-51s%-31s%-7d%-16s\n", submissoes[indice].id, submissoes[indice].data_submissao.dia, submissoes[indice].data_submissao.mes, submissoes[indice].data_submissao.ano, estudantes[indice_estudante].nome, fichas[indice_ficha].nome, exercicios[indice_exercicio].nome, submissoes[indice].linhas, "Nao atribuida");
                }
            }
        }
    }
    else
        printf("\nFicha nao encontrada!!");
    getchar();
    getchar();
}

void submissoes_exercicio(t_estudante estudantes[], int contador_estudantes, t_ficha fichas[], int contador_fichas, t_exercicio exercicios[], int contador_exercicios, t_submissao submissoes[], int contador_submissoes)
{
    int indice_estudante, indice_ficha, indice_exercicio, id_ficha, id_exercicio, contagem_exercicios = 0, contador = 0;
    system("cls");
    todas_fichas(fichas, contador_fichas);
    id_ficha = pedeInteiro("Introduza o ID da ficha a que pertence o exercicio:", 1, contador_fichas);
    indice_ficha = procura_ficha(fichas, contador_fichas, id_ficha);
    if (indice_ficha >= 0)
    {
        contagem_exercicios = conta_exercicios(exercicios, contador_exercicios, id_ficha);
        if (contagem_exercicios > 0)
        {
            id_exercicio = exercicios_de_ficha(fichas, contador_fichas, exercicios, contador_exercicios, indice_ficha);
            indice_exercicio = procura_exercicio(exercicios, contador_exercicios, id_exercicio);
            printf("%-5s %-10s %-50s %-50s %-30s %-6s %-15s\n", "ID", "DATA", "ESTUDANTE", "FICHA", "EXERCICIO", "LINHAS", "CLASSIFICACAO");
            printf("----- ---------- -------------------------------------------------- -------------------------------------------------- ------------------------------ ------ --------------\n");
            for (int indice = 0; indice < contador_submissoes; indice++)
            {
                indice_estudante = procura_estudante_id(estudantes, contador_estudantes, submissoes[indice].id_estudante);
                if (submissoes[indice].id_exercicio == id_exercicio)
                {
                    contador++;
                    if (submissoes[indice].classificacao >= 0)
                        printf("%-5d%3d/%2d/%-5d%-51s%-51s%-31s%-7d%-16.2f\n", submissoes[indice].id, submissoes[indice].data_submissao.dia, submissoes[indice].data_submissao.mes, submissoes[indice].data_submissao.ano, estudantes[indice_estudante].nome, fichas[indice_ficha].nome, exercicios[indice_exercicio].nome, submissoes[indice].linhas, submissoes[indice].classificacao);
                    else
                        printf("%-5d%3d/%2d/%-5d%-51s%-51s%-31s%-7d%-16s\n", submissoes[indice].id, submissoes[indice].data_submissao.dia, submissoes[indice].data_submissao.mes, submissoes[indice].data_submissao.ano, estudantes[indice_estudante].nome, fichas[indice_ficha].nome, exercicios[indice_exercicio].nome, submissoes[indice].linhas, "Nao atribuida");
                }
            }
            if (contador == 0)
                printf("\nAinda nao foram realizadas submissoes para este exercicio !!");
        }
        else
            printf("\nA ficha selecionada ainda nao tem exercicios registados!!");
    }
    else
        printf("\nFicha nao encontrada!!");
    getchar();
    getchar();
}

void alterar_classificacao(t_estudante estudantes[], int contador_estudantes, t_ficha fichas[], int contador_fichas, t_exercicio exercicios[], int contador_exercicios, t_submissao submissoes[], int contador_submissoes)
{
    int id_ficha, id_estudante, id_exercicio, indice_ficha, indice_estudante, indice_exercicio, indice_submissao = -1, contagem_exercicios = 0;
    float classificacao = -1;

    if (contador_submissoes < MAX_SUBMISSAO)
    {
        system("cls");
        id_estudante = pedeInteiro("Introduza o numero de estudante:", MIN_NUMERO_ESTUDANTE, MAX_NUMERO_ESTUDANTE);
        indice_estudante = procura_estudante(estudantes, contador_estudantes, id_estudante);
        if (indice_estudante >= 0)
        {
            todas_fichas(fichas, contador_fichas);
            id_ficha = pedeInteiro("Introduza o ID da ficha a que pertence o exercicio:", 1, contador_fichas);
            indice_ficha = procura_ficha(fichas, contador_fichas, id_ficha);
            if (indice_ficha >= 0)
            {
                contagem_exercicios = conta_exercicios(exercicios, contador_exercicios, id_ficha);
                if (contagem_exercicios > 0)
                {
                    id_exercicio = exercicios_de_ficha(fichas, contador_fichas, exercicios, contador_exercicios, indice_ficha);
                    // procurar submissao
                    indice_submissao = procurar_submissao(submissoes, contador_submissoes, id_ficha, id_exercicio, estudantes[indice_estudante].id);
                    if (indice_submissao >= 0)
                    {
                        classificacao = pedeFloat("Introduza a classificacao:", MIN_CLASSIFICACAO, MAX_CLASSIFICACAO);
                        submissoes[indice_submissao].classificacao = classificacao;
                        printf("\nClassificacao registada com sucesso...");
                    }
                    else
                        printf("\nA submissao que procura ainda nao foi registada!!");
                }
                else
                    printf("\nA ficha selecionada ainda nao tem exercicios registados!!");
            }
            else
                printf("\nFicha nao encontrada!!");
        }
        else
            printf("\nEstudante nao encontrado!!");
    }
    else
        printf("\nAtingiu o numero maximo de submissoes permitido pela aplicacao!!");
    getchar();
    getchar();
}

void total_submissoes_estudante(t_estudante estudantes[], int contador_estudantes, t_submissao submissoes[], int contador_submissoes, int contador_exercicios)
{
    int contador = 0, indice_estudante, numero_estudante;

    system("cls");
    numero_estudante = pedeInteiro("Introduza o numero de estudante:", MIN_NUMERO_ESTUDANTE, MAX_NUMERO_ESTUDANTE);
    indice_estudante = procura_estudante(estudantes, contador_estudantes, numero_estudante);
    if (indice_estudante >= 0)
    {
        printf("\n%-10s %-50s %-12s\n", "N. ALUNO", "ALUNO", "SUBMISSOES");
        printf("--------- -------------------------------------------------- -----------  \n");
        for (int indice = 0; indice < contador_submissoes; indice++)
        {
            if (submissoes[indice].id_estudante == estudantes[indice_estudante].id)
            {
                contador++;
            }
        }
        if (contador == 0)
            printf("\nO aluno %8d - %s ainda nao realizou nenhuma submissao", estudantes[indice_estudante].numero, estudantes[indice_estudante].nome);
        else
            printf("%-10d %-50s %-12d\n", estudantes[indice_estudante].numero, estudantes[indice_estudante].nome, contador);
    }
    else
        printf("\nEstudante nao encontrado!!");
    getchar();
    getchar();
}

void media_submissoes_estudante(t_estudante estudantes[], int contador_estudantes, t_submissao submissoes[], int contador_submissoes, int contador_exercicios)
{
    int contador = 0, indice_estudante, numero_estudante;
    float classificacao_toal = 0, media = 0;

    system("cls");
    numero_estudante = pedeInteiro("Introduza o numero de estudante:", MIN_NUMERO_ESTUDANTE, MAX_NUMERO_ESTUDANTE);
    indice_estudante = procura_estudante(estudantes, contador_estudantes, numero_estudante);
    if (indice_estudante >= 0)
    {
        printf("\n%-10s %-50s %-10s %-16s\n", "N. ALUNO", "ALUNO", "MEDIA", "MEDIA ARREDONDADA");
        printf("---------- -------------------------------------------------- ---------- ----------------- \n");
        for (int indice = 0; indice < contador_submissoes; indice++)
        {
            if (submissoes[indice].id_estudante == estudantes[indice_estudante].id)
            {
                if (submissoes[indice].classificacao >= 0)
                {
                    classificacao_toal = classificacao_toal + submissoes[indice].classificacao;
                }
                contador++;
            }
        }
        media = classificacao_toal / contador;
        printf("%-10d %-50s %-10.2f %-16.0f\n", estudantes[indice_estudante].numero, estudantes[indice_estudante].nome, media, media);
    }
    else
    {
        printf("\nEstudante nao encontrado!!");
    }
    getchar();
    getchar();
}

void percentagem_resolvidos_ficha(t_estudante estudantes[], int contador_estudantes, t_ficha fichas[], int contador_fichas, t_submissao submissoes[], int contador_submissoes, int contador_exercicios)
{
    int contador = 0, indice_estudante, numero_estudante;
    float classificacao_toal = 0, percentagem = 0;

    system("cls");
    numero_estudante = pedeInteiro("Introduza o numero de estudante:", MIN_NUMERO_ESTUDANTE, MAX_NUMERO_ESTUDANTE);
    indice_estudante = procura_estudante(estudantes, contador_estudantes, numero_estudante);
    if (indice_estudante >= 0)
    {
        printf("\n%-50s %-25s %-35s\n", "FICHA", "N. EXERCICIOS RESOLVIDOS", "PERCENTAGEM EXERCICIOS RESOLVIDOS");
        printf("-------------------------------------------------- ------------------------- ----------------------------------- \n");
        for (int indice_fichas = 0; indice_fichas < contador_fichas; indice_fichas++)
        {
            contador = 0;
            for (int indice = 0; indice < contador_submissoes; indice++)
            {
                if ((submissoes[indice].id_estudante == estudantes[indice_estudante].id) && (fichas[indice_fichas].id == submissoes[indice].id_ficha))
                {
                    contador++;
                }
            }
            printf("%-50s %3d em %-19d %d %%\n", fichas[indice_fichas].nome, contador, fichas[indice_fichas].numero_exercicios, contador * 100 / fichas[indice_fichas].numero_exercicios);
        }
    }
    else
    {
        printf("\nEstudante nao encontrado!!");
    }
    getchar();
    getchar();
}
